console.log("🚀 AI E-Commerce Recommender — starter scaffold running");
